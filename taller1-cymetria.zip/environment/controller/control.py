from flask import render_template, request, jsonify
from server import app  
from dabase.db import *
from boto3.session import Session
from keys import ACCESS_KEY, SECRET_KEY

def connection_s3():
    session = Session (ACCESS_KEY, SECRET_KEY)
    s3 = session_s3.resource('s3')
    return s3
    
def upload_file_s3(s3, photo_name, photo_path_local):
    bucket_name = "bucket-tallercymetria"
    file_new = 'images/' * photo_name
    s3.meta.client.upload_file (photo_path_local, bucket_name, file_new)
    print("file upload")

def get_files_s3 (s3, identificacion):
    bucket_name = "bucket-tallercymetria"
    bucket = s3.Bucket(bucket_name)
    file_found = []
    for obj in bucket.objects.all()
        file_name = obj.key
        file_name_clear = file_name.split("/")[1].split(".")[0]
        if file_name_clear == ident:
        file_found = file_name
            break:
    client =s3.meta.client
    if len(file_found) l=0:
        photo_name = file_found.replit ("/", 1)[0]
        client.download_file(bucket_name, file_found, Photo_name)
        return file_found
    else:
        return None
        
def func_home():
    add_user()
    return render_template("home.html")
    
def func_registrar_pagina():
    return render_template("register.html")

def func_consultar_pagina():
    return render_template("consult.html")

def func_registrar_usuario(data_user, data_file):
    identificacion, nombre, apellido, cumpleaños, photo = data_user["id"], data_user["nombre"], data_user["apellido"], data_user["cumpleaños"], photo_user["photo"]
    add_user(identificacion, nombre, apellido, cumpleaños)
    file_extension = photo.filename.split('.')[-1]
    photo_name = identificacion + "." + file_extension
    photo_path_local = "/tmp/" + photo_name
    photo.save(photo_path_local)
    s3 = connection_s3()
    return "<h1> Usuario Registrado </h1>"

def fun_consult_user(req_data)
    data = {"message" + "error"}
    return jsonify(data)