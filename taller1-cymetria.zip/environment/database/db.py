import pymysql

db_host = "db-cym.cd4c2m86wtr6.us-east-2.rds.amazonaws.com"
db_user = "admin"
db_passw = "12345678"
db_name = "pruebasdb"

def connectionSQL():
    try:
        connectionSQL = pymysql.connect(    
            host = db_host,
            user = db_user,
            password = db_passw,
            database = db_name)
        print("conexión exitosa")
        return connection
    except:
        print("Error de conexion")  
        return None
        
def add_user(identificacion, nombre, apellido, cumpleaños):
    instruction = "INSERT INTO usuarios VALUES (" + identificacion + ", '" + nombre + "', '" + apellido + "', '" + cumpleaños + "')"
    connection = connectionSQL()
    cursor =connection.cursor()
    try:
        cursor.execute(instruction)
        connection.commit()
        print("Usuario agregado")
    except:
        print("Error cuando se adiciona el usuario")
    return True
    
def consult_user(identificacion):
    return None
