document.querySelector("button-consultar").addEventListener('click', consultar_usuario)

function consultar_usuario(){
}


