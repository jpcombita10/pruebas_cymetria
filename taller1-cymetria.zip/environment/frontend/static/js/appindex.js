document.querySelector("button-registrar").addEventListener('click', register_view)
document.querySelector("button-consultar").addEventListener('click', consulter_view)

function register_view () {
    window.location = "/registrar_pagina"
}

function consulter_view () {
    window.location ="/consultar_pagina"
}