from flask import render_template, request
from server import app
from database.db import add_user

@app.route('/')
def func_home():
    add_user()
    return render_template("home.html")
    
@app.route('/register_page')
def func_registrar_pagina():
    return func_registrar_pagina()

@app.route("/consult_page")
def func_consultar_pagina():
    return func_consultar_pagina()

@app.route("/registrar_usuario", methods = ["post"])
def func_registrar_usuario():
     return func_registrar_usuario(request.form, request.files)

@app.route("/consultar_usuario", methods = ["post"])
def func_consultar_usuario():
    request_data =request.get_json()
    return func_consultar_usuario(request_data)   
    
    

        